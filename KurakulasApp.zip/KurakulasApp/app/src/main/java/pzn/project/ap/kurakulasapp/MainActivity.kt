package pzn.project.ap.kurakulasapp

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import dagger.hilt.android.AndroidEntryPoint
import pzn.project.ap.kurakulasapp.ui.AddAppointmentScreen
import pzn.project.ap.kurakulasapp.ui.LoginScreen
import pzn.project.ap.kurakulasapp.ui.MainPanelScreen
import pzn.project.ap.kurakulasapp.ui.theme.KurakulasAppTheme
import pzn.project.ap.kurakulasapp.data.model.LoginResponse
import androidx.hilt.navigation.compose.hiltViewModel
import pzn.project.ap.kurakulasapp.ui.viewmodel.MainPanelViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            KurakulasAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var isLoggedIn by remember { mutableStateOf(false) }
                    val mainPanelViewModel: MainPanelViewModel = hiltViewModel()

                    if (isLoggedIn) {
                        Log.d("MainActivity", "Showing MainPanelScreen")
                        MainPanelScreen(
                            onNavigateToAddAppointment = {
                                // Handle navigation to AddAppointmentScreen
                            },
                            onLogout = {
                                mainPanelViewModel.clearUserData()
                                isLoggedIn = false
                                Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
                            }
                        )
                    } else {
                        Log.d("MainActivity", "Showing LoginScreen")
                        LoginScreen(
                            onLoginSuccess = { loginResponse ->
                                Log.d("MainActivity", "Login success callback received with user: ${loginResponse.user?.firstName} ${loginResponse.user?.lastName}")
                                mainPanelViewModel.updateUserData(loginResponse)
                                isLoggedIn = true
                                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }
}