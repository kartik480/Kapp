package pzn.project.ap.kurakulasapp.data.api

object ApiConfig {
    const val BASE_URL = "http://10.0.2.2/backend/"
    //const val BASE_URL = "https://quickidefender.com/kurakulasapp/"
}