package pzn.project.ap.kurakulasapp.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import pzn.api.ApiService
import pzn.api.DsaDropdownOptions
import javax.inject.Inject

data class DsaCodeState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val vendorBanks: List<String> = emptyList(),
    val loanTypes: List<String> = emptyList(),
    val branchStates: List<String> = emptyList(),
    val branchLocations: List<String> = emptyList()
)

@HiltViewModel
class DsaCodeViewModel @Inject constructor(
    private val apiService: ApiService
) : ViewModel() {

    private val _state = MutableStateFlow(DsaCodeState())
    val state: StateFlow<DsaCodeState> = _state.asStateFlow()

    init {
        loadDropdownOptions()
    }

    fun loadDropdownOptions() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                val response = apiService.getDsaDropdownOptions()
                if (response.isSuccessful) {
                    response.body()?.data?.let { options ->
                        _state.value = _state.value.copy(
                            isLoading = false,
                            vendorBanks = options.vendor_banks,
                            loanTypes = options.loan_types,
                            branchStates = options.branch_states,
                            branchLocations = options.branch_locations
                        )
                    }
                } else {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = "Failed to load dropdown options"
                    )
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "An error occurred"
                )
            }
        }
    }
} 