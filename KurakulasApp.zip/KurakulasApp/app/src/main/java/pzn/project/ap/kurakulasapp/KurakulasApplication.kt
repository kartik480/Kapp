package pzn.project.ap.kurakulasapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class KurakulasApplication : Application() 