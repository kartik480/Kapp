package pzn.project.ap.kurakulasapp.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import pzn.project.ap.kurakulasapp.data.repository.LoginRepository
import pzn.project.ap.kurakulasapp.data.model.LoginResponse
import javax.inject.Inject

@HiltViewModel
class MainPanelViewModel @Inject constructor(
    private val loginRepository: LoginRepository
) : ViewModel() {
    private val _userFirstName = MutableStateFlow<String?>(null)
    val userFirstName: StateFlow<String?> = _userFirstName.asStateFlow()

    private val _userLastName = MutableStateFlow<String?>(null)
    val userLastName: StateFlow<String?> = _userLastName.asStateFlow()

    private val _userEmail = MutableStateFlow<String?>(null)
    val userEmail: StateFlow<String?> = _userEmail.asStateFlow()

    init {
        // Check for existing session
        val storedLoginResponse = loginRepository.getStoredLoginResponse()
        if (storedLoginResponse != null) {
            updateUserData(storedLoginResponse)
        } else {
            clearUserData()
        }
    }

    fun updateUserData(loginResponse: LoginResponse) {
        Log.d("MainPanelViewModel", "Updating user data with response: $loginResponse")
        loginResponse.user?.let { user ->
            _userFirstName.value = user.firstName
            _userLastName.value = user.lastName
            _userEmail.value = user.emailId
            Log.d("MainPanelViewModel", "Updated user data - First Name: ${user.firstName}, Last Name: ${user.lastName}, Email: ${user.emailId}")
        } ?: run {
            Log.e("MainPanelViewModel", "User data is null in the response")
        }
    }

    fun clearUserData() {
        _userFirstName.value = null
        _userLastName.value = null
        _userEmail.value = null
        Log.d("MainPanelViewModel", "Cleared user data")
    }

    fun logout() {
        viewModelScope.launch {
            try {
                loginRepository.logout()
                clearUserData()
                Log.d("MainPanelViewModel", "Logout successful")
            } catch (e: Exception) {
                Log.e("MainPanelViewModel", "Logout failed", e)
            }
        }
    }
} 