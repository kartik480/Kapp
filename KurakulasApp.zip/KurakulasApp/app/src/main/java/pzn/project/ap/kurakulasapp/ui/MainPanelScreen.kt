package pzn.project.ap.kurakulasapp.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.HorizontalPagerIndicator
import com.google.accompanist.pager.rememberPagerState
import kotlinx.coroutines.launch
import androidx.hilt.navigation.compose.hiltViewModel
import pzn.project.ap.kurakulasapp.ui.viewmodel.MainPanelViewModel
import pzn.AddAppointmentPanel
import pzn.project.ap.kurakulasapp.ui.viewmodels.DsaCodeViewModel
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPagerApi::class)
@Composable
fun MainPanelScreen(
    onMenuClick: () -> Unit = {},
    onHelpClick: () -> Unit = {},
    onAccountClick: () -> Unit = {},
    onNavigateToAddAppointment: () -> Unit,
    onLogout: () -> Unit = {},
    viewModel: MainPanelViewModel = hiltViewModel()
) {
    var selectedTab by remember { mutableStateOf(0) }
    var showAddAppointment by remember { mutableStateOf(false) }
    var showMyAccount by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showSalAppointmentPanel by remember { mutableStateOf(false) }
    var showSenpAppointmentPanel by remember { mutableStateOf(false) }
    var showSepAppointmentPanel by remember { mutableStateOf(false) }
    var showNriAppointmentPanel by remember { mutableStateOf(false) }
    var showEducationalAppointmentPanel by remember { mutableStateOf(false) }
    var showTeamSalAppointmentPanel by remember { mutableStateOf(false) }
    var showTeamSenpAppointmentPanel by remember { mutableStateOf(false) }
    var showTeamSepAppointmentPanel by remember { mutableStateOf(false) }
    var showTeamNriAppointmentPanel by remember { mutableStateOf(false) }
    var showTeamEducationalAppointmentPanel by remember { mutableStateOf(false) }
    var showAddAgentPanel by remember { mutableStateOf(false) }
    var showMyAgentPanel by remember { mutableStateOf(false) }
    var showDsaCodePanel by remember { mutableStateOf(false) }
    var showBankersPanel by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(onClick = { 
                            scope.launch {
                                drawerState.open()
                            }
                        }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                        
                        Text(
                            text = "Kurakulas",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        
                        Row {
                            IconButton(onClick = { showHelp = true }) {
                                Icon(Icons.Default.Info, contentDescription = "Help")
                            }
                            IconButton(onClick = { showMyAccount = true }) {
                                Icon(Icons.Default.Person, contentDescription = "My Account")
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = "Appointments") },
                    label = { Text("Appointments") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.List, contentDescription = "Files") },
                    label = { Text("Files") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.MoreVert, contentDescription = "More") },
                    label = { Text("More") }
                )
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize()) {
            // Main content
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Image Slider
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(Color.Gray)
                    ) {
                        val pagerState = rememberPagerState()
                        
                        HorizontalPager(
                            count = 3,
                            state = pagerState,
                            modifier = Modifier.fillMaxSize()
                        ) { page ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.LightGray)
                            ) {
                                Text(
                                    text = "Image ${page + 1}",
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                        }
                        
                        HorizontalPagerIndicator(
                            pagerState = pagerState,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(16.dp)
                        )
                    }
                }

                // Welcome Box
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Welcome to Kurakulas",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            val firstName by viewModel.userFirstName.collectAsState()
                            val lastName by viewModel.userLastName.collectAsState()
                            Text(
                                text = if (firstName != null && lastName != null) {
                                    "$firstName $lastName"
                                } else {
                                    "User"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Your Financial Partner",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                        }
                    }
                }

                // Add Statistics Section here
                item {
                    StatisticsSection()
                }

                when (selectedTab) {
                    0 -> {
                        // Appointments Section
                        item {
                            if (selectedTab == 0) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp)
                                ) {
                                    Text(
                                        text = "Appointments",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        items(appointments) { appointment ->
                            AppointmentCard(
                                appointment = appointment,
                                onAddAppointmentClick = { showAddAppointment = true },
                                onSalAppointmentClick = { showSalAppointmentPanel = true },
                                onSenpAppointmentClick = { showSenpAppointmentPanel = true },
                                onSepAppointmentClick = { showSepAppointmentPanel = true },
                                onNriAppointmentClick = { showNriAppointmentPanel = true },
                                onEducationalAppointmentClick = { showEducationalAppointmentPanel = true },
                                onTeamSalAppointmentClick = { showTeamSalAppointmentPanel = true },
                                onTeamSenpAppointmentClick = { showTeamSenpAppointmentPanel = true },
                                onTeamSepAppointmentClick = { showTeamSepAppointmentPanel = true },
                                onTeamNriAppointmentClick = { showTeamNriAppointmentPanel = true },
                                onTeamEducationalAppointmentClick = { showTeamEducationalAppointmentPanel = true }
                            )
                        }
                    }
                    1 -> {
                        // Files Section
                        item {
                            Text(
                                text = "Files",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                        item {
                            FileUploadCard()
                        }
                    }
                    2 -> {
                        // More Section
                        item {
                            Text(
                                text = "More Options",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                        item {
                            MoreOptionCard(
                                title = "DSA Code",
                                onClick = { showDsaCodePanel = true }
                            )
                        }
                        item {
                            MoreOptionCard(
                                title = "Bankers",
                                onClick = { showBankersPanel = true }
                            )
                        }
                    }
                }
            }

            if (showSalAppointmentPanel) {
                SalAppointmentPanel(
                    onDismiss = { showSalAppointmentPanel = false }
                )
            }

            if (showSenpAppointmentPanel) {
                SenpAppointmentPanel(
                    onDismiss = { showSenpAppointmentPanel = false }
                )
            }

            if (showSepAppointmentPanel) {
                SepAppointmentPanel(
                    onDismiss = { showSepAppointmentPanel = false }
                )
            }

            if (showNriAppointmentPanel) {
                NriAppointmentPanel(onDismiss = { showNriAppointmentPanel = false })
            }

            if (showEducationalAppointmentPanel) {
                EducationalAppointmentPanel(onDismiss = { showEducationalAppointmentPanel = false })
            }

            if (showTeamSalAppointmentPanel) {
                TeamSalAppointmentPanel(onDismiss = { showTeamSalAppointmentPanel = false })
            }

            if (showTeamSenpAppointmentPanel) {
                TeamSenpAppointmentPanel(onDismiss = { showTeamSenpAppointmentPanel = false })
            }

            if (showTeamSepAppointmentPanel) {
                TeamSepAppointmentPanel(onDismiss = { showTeamSepAppointmentPanel = false })
            }

            if (showTeamNriAppointmentPanel) {
                TeamNriAppointmentPanel(onDismiss = { showTeamNriAppointmentPanel = false })
            }

            if (showTeamEducationalAppointmentPanel) {
                TeamEducationalAppointmentPanel(onDismiss = { showTeamEducationalAppointmentPanel = false })
            }

            if (showAddAgentPanel) {
                AddAgentPanel(onDismiss = { showAddAgentPanel = false })
            }

            if (showMyAgentPanel) {
                MyAgentPanel(onDismiss = { showMyAgentPanel = false })
            }

            if (showDsaCodePanel) {
                DsaCodePanel(
                    onDismiss = { showDsaCodePanel = false },
                    viewModel = hiltViewModel()
                )
            }

            if (showBankersPanel) {
                BankersPanel(onDismiss = { showBankersPanel = false })
            }

            // Drawer
            if (drawerState.isOpen) {
                Surface(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(300.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            "Menu",
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                        Divider()
                        
                        // Drawer Items
                        DrawerItem(
                            icon = Icons.Default.Dashboard,
                            text = "Dashboard",
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                }
                            }
                        )
                        
                        DrawerItem(
                            icon = Icons.Default.Person,
                            text = "Profile",
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                }
                            }
                        )
                        
                        DrawerItem(
                            icon = Icons.Default.Settings,
                            text = "Settings",
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                }
                            }
                        )
                        
                        DrawerItem(
                            icon = Icons.Default.Help,
                            text = "Help & Support",
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                }
                            }
                        )
                        
                        DrawerItem(
                            icon = Icons.Default.Info,
                            text = "About",
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                }
                            }
                        )
                        
                        DrawerItem(
                            icon = Icons.Default.ExitToApp,
                            text = "Logout",
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                    viewModel.logout()
                                    onLogout()
                                }
                            }
                        )
                    }
                }
            }

            // Show Add Appointment Panel
            if (showAddAppointment) {
                AddAppointmentPanel(
                    onNavigateBack = { showAddAppointment = false },
                    context = LocalContext.current
                )
            }

            // Show My Account Panel
            if (showMyAccount) {
                MyAccountPanel(
                    onNavigateBack = { showMyAccount = false },
                    onLogout = onLogout,
                    viewModel = viewModel
                )
            }

            // Show Help Panel
            if (showHelp) {
                HelpPanel(
                    onDismiss = { showHelp = false }
                )
            }
        }
    }
}

@Composable
private fun DrawerItem(
    icon: ImageVector,
    text: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun AppointmentCard(
    appointment: String,
    onAddAppointmentClick: () -> Unit,
    onSalAppointmentClick: () -> Unit,
    onSenpAppointmentClick: () -> Unit,
    onSepAppointmentClick: () -> Unit,
    onNriAppointmentClick: () -> Unit,
    onEducationalAppointmentClick: () -> Unit,
    onTeamSalAppointmentClick: () -> Unit,
    onTeamSenpAppointmentClick: () -> Unit,
    onTeamSepAppointmentClick: () -> Unit,
    onTeamNriAppointmentClick: () -> Unit,
    onTeamEducationalAppointmentClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { 
                when (appointment) {
                    "Add Appointment" -> onAddAppointmentClick()
                    "My SAL Appointment" -> onSalAppointmentClick()
                    "My SENP Appointment" -> onSenpAppointmentClick()
                    "My SEP Appointment" -> onSepAppointmentClick()
                    "My NRI Appointment" -> onNriAppointmentClick()
                    "My Educational Appointment" -> onEducationalAppointmentClick()
                    "Team SAL Appointment" -> onTeamSalAppointmentClick()
                    "Team SENP Appointment" -> onTeamSenpAppointmentClick()
                    "Team SEP Appointment" -> onTeamSepAppointmentClick()
                    "Team NRI Appointment" -> onTeamNriAppointmentClick()
                    "Team Educational Appointment" -> onTeamEducationalAppointmentClick()
                }
            },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.DateRange, contentDescription = null)
                Spacer(modifier = Modifier.width(16.dp))
                Text(appointment, fontSize = 16.sp)
            }
            if (appointment != "Add Appointment") {
                Text("0", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileUploadCard() {
    var selectedFileType by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val fileTypes = listOf("PNG", "JPEG", "PDF")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Choose File",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedFileType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("File Type") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .width(120.dp)
                            .menuAnchor()
                    )

                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        fileTypes.forEach { fileType ->
                            DropdownMenuItem(
                                text = { Text(fileType) },
                                onClick = {
                                    selectedFileType = fileType
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            Button(
                onClick = {
                    if (selectedFileType.isNotEmpty()) {
                        // TODO: Implement file upload functionality
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                enabled = selectedFileType.isNotEmpty()
            ) {
                Text("Submit")
            }
        }
    }
}

@Composable
fun AgentCard(title: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Person, contentDescription = null)
            Spacer(modifier = Modifier.width(16.dp))
            Text(title, fontSize = 16.sp)
        }
    }
}

@Composable
fun MoreOptionCard(title: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Settings, contentDescription = null)
            Spacer(modifier = Modifier.width(16.dp))
            Text(title, fontSize = 16.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalAppointmentPanel(onDismiss: () -> Unit) {
    var mobileNumber by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Appointment Salaried List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Search Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Search Appointments",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { if (it.length <= 10) mobileNumber = it },
                        label = { Text("Enter Mobile Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { mobileNumber = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (mobileNumber.length == 10) {
                                    // TODO: Implement search functionality
                                }
                            }
                        ) {
                            Text("Search")
                        }
                    }
                }
            }

            // Results Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Appointment Results",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Placeholder for results
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Appointment list will be shown here")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SenpAppointmentPanel(onDismiss: () -> Unit) {
    var mobileNumber by remember { mutableStateOf("") }
    
    // Sample data for the table
    val appointments = remember {
        listOf(
            AppointmentData("9876543210", "John Doe", "john@example.com", "Agent1"),
            AppointmentData("9876543211", "Jane Smith", "jane@example.com", "Agent2"),
            AppointmentData("9876543212", "Mike Johnson", "mike@example.com", "Agent3")
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Appointment SENP List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Search Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { if (it.length <= 10) mobileNumber = it },
                        label = { Text("Enter Mobile Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { mobileNumber = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (mobileNumber.length == 10) {
                                    // TODO: Implement search functionality
                                }
                            }
                        ) {
                            Text("Filter")
                        }
                    }
                }
            }

            // Table Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Mobile Number",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Lead Name",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Email ID",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Created By",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Actions",
                            modifier = Modifier.weight(0.5f),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Table Content
                    appointments.forEach { appointment ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                appointment.mobileNumber,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                appointment.leadName,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                appointment.emailId,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                appointment.createdBy,
                                modifier = Modifier.weight(1f)
                            )
                            Row(
                                modifier = Modifier.weight(0.5f),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(onClick = { /* TODO: View action */ }) {
                                    Icon(Icons.Default.Visibility, contentDescription = "View")
                                }
                                IconButton(onClick = { /* TODO: Edit action */ }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit")
                                }
                            }
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SepAppointmentPanel(onDismiss: () -> Unit) {
    var mobileNumber by remember { mutableStateOf("") }
    
    // Sample data for the table
    val appointments = remember {
        listOf(
            AppointmentData("9876543210", "John Doe", "john@example.com", "Agent1"),
            AppointmentData("9876543211", "Jane Smith", "jane@example.com", "Agent2"),
            AppointmentData("9876543212", "Mike Johnson", "mike@example.com", "Agent3")
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Database SEP List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Search Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { if (it.length <= 10) mobileNumber = it },
                        label = { Text("Enter Mobile Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { mobileNumber = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (mobileNumber.length == 10) {
                                    // TODO: Implement search functionality
                                }
                            }
                        ) {
                            Text("Filter")
                        }
                    }
                }
            }

            // Table Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Mobile Number",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Lead Name",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Email ID",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Created By",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Action",
                            modifier = Modifier.weight(0.5f),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Table Content
                    appointments.forEach { appointment ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                appointment.mobileNumber,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                appointment.leadName,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                appointment.emailId,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                appointment.createdBy,
                                modifier = Modifier.weight(1f)
                            )
                            Row(
                                modifier = Modifier.weight(0.5f),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(onClick = { /* TODO: View action */ }) {
                                    Icon(Icons.Default.Visibility, contentDescription = "View")
                                }
                                IconButton(onClick = { /* TODO: Edit action */ }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit")
                                }
                            }
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NriAppointmentPanel(onDismiss: () -> Unit) {
    var mobileNumber by remember { mutableStateOf("") }
    
    val appointments = remember {
        listOf(
            AppointmentData("9876543210", "John Doe", "john@example.com", "Agent1"),
            AppointmentData("9876543211", "Jane Smith", "jane@example.com", "Agent2"),
            AppointmentData("9876543212", "Mike Johnson", "mike@example.com", "Agent3")
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Database NRI List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Search Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { if (it.length <= 10) mobileNumber = it },
                        label = { Text("Enter Mobile Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { mobileNumber = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (mobileNumber.length == 10) {
                                    // TODO: Implement search functionality
                                }
                            }
                        ) {
                            Text("Filter")
                        }
                    }
                }
            }

            // Table Section
            AppointmentTable(appointments = appointments)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EducationalAppointmentPanel(onDismiss: () -> Unit) {
    var mobileNumber by remember { mutableStateOf("") }
    
    val appointments = remember {
        listOf(
            AppointmentData("9876543210", "John Doe", "john@example.com", "Agent1"),
            AppointmentData("9876543211", "Jane Smith", "jane@example.com", "Agent2"),
            AppointmentData("9876543212", "Mike Johnson", "mike@example.com", "Agent3")
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Appointment Educational List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Search Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { if (it.length <= 10) mobileNumber = it },
                        label = { Text("Enter Mobile Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { mobileNumber = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (mobileNumber.length == 10) {
                                    // TODO: Implement search functionality
                                }
                            }
                        ) {
                            Text("Filter")
                        }
                    }
                }
            }

            // Table Section
            AppointmentTable(appointments = appointments)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamSalAppointmentPanel(onDismiss: () -> Unit) {
    var selectedUser by remember { mutableStateOf("") }
    val users = remember { listOf("User 1", "User 2", "User 3", "User 4") }
    var expanded by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Team Appointment",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // User Selection Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedUser,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select User") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            users.forEach { user ->
                                DropdownMenuItem(
                                    text = { Text(user) },
                                    onClick = {
                                        selectedUser = user
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { selectedUser = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (selectedUser.isNotEmpty()) {
                                    // TODO: Implement show data functionality
                                }
                            }
                        ) {
                            Text("Show Data")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamSenpAppointmentPanel(onDismiss: () -> Unit) {
    var selectedUser by remember { mutableStateOf("") }
    val users = remember { listOf("User 1", "User 2", "User 3", "User 4") }
    var expanded by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Team Appointment",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // User Selection Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedUser,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select User") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            users.forEach { user ->
                                DropdownMenuItem(
                                    text = { Text(user) },
                                    onClick = {
                                        selectedUser = user
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { selectedUser = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (selectedUser.isNotEmpty()) {
                                    // TODO: Implement show data functionality
                                }
                            }
                        ) {
                            Text("Show Data")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamSepAppointmentPanel(onDismiss: () -> Unit) {
    var selectedUser by remember { mutableStateOf("") }
    val users = remember { listOf("User 1", "User 2", "User 3", "User 4") }
    var expanded by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Team Appointment",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // User Selection Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedUser,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select User") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            users.forEach { user ->
                                DropdownMenuItem(
                                    text = { Text(user) },
                                    onClick = {
                                        selectedUser = user
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { selectedUser = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (selectedUser.isNotEmpty()) {
                                    // TODO: Implement show data functionality
                                }
                            }
                        ) {
                            Text("Show Data")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamNriAppointmentPanel(onDismiss: () -> Unit) {
    var selectedUser by remember { mutableStateOf("") }
    val users = remember { listOf("User 1", "User 2", "User 3", "User 4") }
    var expanded by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Team Appointment",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // User Selection Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedUser,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select User") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            users.forEach { user ->
                                DropdownMenuItem(
                                    text = { Text(user) },
                                    onClick = {
                                        selectedUser = user
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { selectedUser = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (selectedUser.isNotEmpty()) {
                                    // TODO: Implement show data functionality
                                }
                            }
                        ) {
                            Text("Show Data")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamEducationalAppointmentPanel(onDismiss: () -> Unit) {
    var selectedUser by remember { mutableStateOf("") }
    val users = remember { listOf("User 1", "User 2", "User 3", "User 4") }
    var expanded by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Team Appointment",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // User Selection Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedUser,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select User") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            users.forEach { user ->
                                DropdownMenuItem(
                                    text = { Text(user) },
                                    onClick = {
                                        selectedUser = user
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { selectedUser = "" },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                if (selectedUser.isNotEmpty()) {
                                    // TODO: Implement show data functionality
                                }
                            }
                        ) {
                            Text("Show Data")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppointmentTable(appointments: List<AppointmentData>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Mobile Number",
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Lead Name",
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Email ID",
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Created By",
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Actions",
                    modifier = Modifier.weight(0.5f),
                    fontWeight = FontWeight.Bold
                )
            }

            // Table Content
            appointments.forEach { appointment ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        appointment.mobileNumber,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        appointment.leadName,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        appointment.emailId,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        appointment.createdBy,
                        modifier = Modifier.weight(1f)
                    )
                    Row(
                        modifier = Modifier.weight(0.5f),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { /* TODO: View action */ }) {
                            Icon(Icons.Default.Visibility, contentDescription = "View")
                        }
                        IconButton(onClick = { /* TODO: Edit action */ }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                    }
                }
                Divider()
            }
        }
    }
}

data class AppointmentData(
    val mobileNumber: String,
    val leadName: String,
    val emailId: String,
    val createdBy: String
)

private val appointments = listOf(
    "Add Appointment",
    "My SAL Appointment",
    "My SENP Appointment",
    "My SEP Appointment",
    "My NRI Appointment",
    "My Educational Appointment",
    "Team SAL Appointment",
    "Team SENP Appointment",
    "Team SEP Appointment",
    "Team NRI Appointment",
    "Team Educational Appointment"
)

private val files = listOf(
    "Recent Documents",
    "Shared Files",
    "My Documents",
    "Team Documents",
    "Archived Files"
)

private val moreOptions = listOf(
    "Settings",
    "Help & Support",
    "About",
    "Logout"
)

@Preview(showBackground = true)
@Composable
fun MainPanelScreenPreview() {
    MaterialTheme {
        MainPanelScreen(
            onMenuClick = {},
            onHelpClick = {},
            onAccountClick = {},
            onNavigateToAddAppointment = {}
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAgentPanel(onDismiss: () -> Unit) {
    var phoneNumber by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var companyName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var alternativePhone by remember { mutableStateOf("") }
    
    var selectedBranchState by remember { mutableStateOf("") }
    var selectedPartnerType by remember { mutableStateOf("") }
    var selectedBranchLocation by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf("") }
    
    var branchStateExpanded by remember { mutableStateOf(false) }
    var partnerTypeExpanded by remember { mutableStateOf(false) }
    var branchLocationExpanded by remember { mutableStateOf(false) }
    
    val branchStates = listOf("State 1", "State 2", "State 3")
    val partnerTypes = listOf("Type 1", "Type 2", "Type 3")
    val branchLocations = listOf("Location 1", "Location 2", "Location 3")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Add Agent Details",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Phone Number
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { if (it.length <= 10) phoneNumber = it },
                        label = { Text("Phone Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                        )
                    )

                    // Full Name
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    )

                    // Company Name
                    OutlinedTextField(
                        value = companyName,
                        onValueChange = { companyName = it },
                        label = { Text("Company Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    )

                    // Email
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Email
                        )
                    )

                    // Branch State Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchStateExpanded,
                        onExpandedChange = { branchStateExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchState,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch State") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchStateExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchStateExpanded,
                            onDismissRequest = { branchStateExpanded = false }
                        ) {
                            branchStates.forEach { state ->
                                DropdownMenuItem(
                                    text = { Text(state) },
                                    onClick = {
                                        selectedBranchState = state
                                        branchStateExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Address
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Address") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        minLines = 3
                    )

                    // Alternative Phone
                    OutlinedTextField(
                        value = alternativePhone,
                        onValueChange = { if (it.length <= 10) alternativePhone = it },
                        label = { Text("Alternative Phone Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone
                        )
                    )

                    // Partner Type Dropdown
                    ExposedDropdownMenuBox(
                        expanded = partnerTypeExpanded,
                        onExpandedChange = { partnerTypeExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedPartnerType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Type of Partner") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = partnerTypeExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = partnerTypeExpanded,
                            onDismissRequest = { partnerTypeExpanded = false }
                        ) {
                            partnerTypes.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type) },
                                    onClick = {
                                        selectedPartnerType = type
                                        partnerTypeExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Branch Location Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchLocationExpanded,
                        onExpandedChange = { branchLocationExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchLocation,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch Location") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchLocationExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchLocationExpanded,
                            onDismissRequest = { branchLocationExpanded = false }
                        ) {
                            branchLocations.forEach { location ->
                                DropdownMenuItem(
                                    text = { Text(location) },
                                    onClick = {
                                        selectedBranchLocation = location
                                        branchLocationExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Visiting Card File Selection
                    OutlinedButton(
                        onClick = { /* TODO: Implement file selection */ },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text("Choose Visiting Card")
                    }

                    // Submit Button
                    Button(
                        onClick = {
                            // TODO: Implement submit functionality
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Submit")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyAgentPanel(onDismiss: () -> Unit) {
    var selectedAgentType by remember { mutableStateOf("") }
    var selectedBranchState by remember { mutableStateOf("") }
    var selectedBranchLocation by remember { mutableStateOf("") }
    
    var agentTypeExpanded by remember { mutableStateOf(false) }
    var branchStateExpanded by remember { mutableStateOf(false) }
    var branchLocationExpanded by remember { mutableStateOf(false) }
    
    val agentTypes = listOf("Type 1", "Type 2", "Type 3")
    val branchStates = listOf("State 1", "State 2", "State 3")
    val branchLocations = listOf("Location 1", "Location 2", "Location 3")

    // Sample data for the table
    val agents = remember {
        listOf(
            AgentData(
                fullName = "John Doe",
                companyName = "Company 1",
                mobile = "9876543210",
                agentType = "Type 1",
                branchState = "State 1",
                branchLocation = "Location 1",
                createdBy = "Admin"
            ),
            AgentData(
                fullName = "Jane Smith",
                companyName = "Company 2",
                mobile = "9876543211",
                agentType = "Type 2",
                branchState = "State 2",
                branchLocation = "Location 2",
                createdBy = "Admin"
            )
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Agent List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Filter Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Agent Type Dropdown
                    ExposedDropdownMenuBox(
                        expanded = agentTypeExpanded,
                        onExpandedChange = { agentTypeExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedAgentType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Agent Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = agentTypeExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = agentTypeExpanded,
                            onDismissRequest = { agentTypeExpanded = false }
                        ) {
                            agentTypes.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type) },
                                    onClick = {
                                        selectedAgentType = type
                                        agentTypeExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Branch State Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchStateExpanded,
                        onExpandedChange = { branchStateExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchState,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch State") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchStateExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchStateExpanded,
                            onDismissRequest = { branchStateExpanded = false }
                        ) {
                            branchStates.forEach { state ->
                                DropdownMenuItem(
                                    text = { Text(state) },
                                    onClick = {
                                        selectedBranchState = state
                                        branchStateExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Branch Location Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchLocationExpanded,
                        onExpandedChange = { branchLocationExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchLocation,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch Location") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchLocationExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchLocationExpanded,
                            onDismissRequest = { branchLocationExpanded = false }
                        ) {
                            branchLocations.forEach { location ->
                                DropdownMenuItem(
                                    text = { Text(location) },
                                    onClick = {
                                        selectedBranchLocation = location
                                        branchLocationExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Filter and Reset Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = {
                                selectedAgentType = ""
                                selectedBranchState = ""
                                selectedBranchLocation = ""
                            },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                // TODO: Implement filter functionality
                            }
                        ) {
                            Text("Filter")
                        }
                    }
                }
            }

            // Table Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Full Name",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Company Name",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Mobile",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Agent Type",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Branch State",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Branch Location",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Table Content
                    agents.forEach { agent ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                agent.fullName,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                agent.companyName,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                agent.mobile,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                agent.agentType,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                agent.branchState,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                agent.branchLocation,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

data class AgentData(
    val fullName: String,
    val companyName: String,
    val mobile: String,
    val agentType: String,
    val branchState: String,
    val branchLocation: String,
    val createdBy: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DsaCodePanel(
    onDismiss: () -> Unit,
    viewModel: DsaCodeViewModel = hiltViewModel()
) {
    var selectedVendorBank by remember { mutableStateOf("") }
    var selectedLoanType by remember { mutableStateOf("") }
    var selectedBranchState by remember { mutableStateOf("") }
    var selectedBranchLocation by remember { mutableStateOf("") }
    
    var vendorBankExpanded by remember { mutableStateOf(false) }
    var loanTypeExpanded by remember { mutableStateOf(false) }
    var branchStateExpanded by remember { mutableStateOf(false) }
    var branchLocationExpanded by remember { mutableStateOf(false) }

    val state by viewModel.state.collectAsState()

    // Sample data for the table
    val dsaCodes = remember {
        listOf(
            DsaCodeData(
                vendorBank = "Bank 1",
                dsaCode = "DSA001",
                dsaName = "DSA Name 1",
                loanType = "Type 1",
                state = "State 1",
                location = "Location 1"
            ),
            DsaCodeData(
                vendorBank = "Bank 2",
                dsaCode = "DSA002",
                dsaName = "DSA Name 2",
                loanType = "Type 2",
                state = "State 2",
                location = "Location 2"
            )
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "DSA Code List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Filter Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Vendor Bank Dropdown
                    ExposedDropdownMenuBox(
                        expanded = vendorBankExpanded,
                        onExpandedChange = { vendorBankExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedVendorBank,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Vendor Bank") },
                            trailingIcon = { 
                                if (state.isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = vendorBankExpanded)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp),
                            isError = state.error != null,
                            supportingText = {
                                if (state.error != null) {
                                    Text(state.error!!, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        )

                        ExposedDropdownMenu(
                            expanded = vendorBankExpanded,
                            onDismissRequest = { vendorBankExpanded = false }
                        ) {
                            if (state.isLoading) {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator()
                                }
                            } else if (state.vendorBanks.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No banks available") },
                                    onClick = { }
                                )
                            } else {
                                state.vendorBanks.forEach { bank ->
                                    DropdownMenuItem(
                                        text = { Text(bank) },
                                        onClick = {
                                            selectedVendorBank = bank
                                            vendorBankExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Loan Type Dropdown
                    ExposedDropdownMenuBox(
                        expanded = loanTypeExpanded,
                        onExpandedChange = { loanTypeExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedLoanType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Loan Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = loanTypeExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = loanTypeExpanded,
                            onDismissRequest = { loanTypeExpanded = false }
                        ) {
                            if (state.isLoading) {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator()
                                }
                            } else if (state.loanTypes.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No loan types available") },
                                    onClick = { }
                                )
                            } else {
                                state.loanTypes.forEach { type ->
                                    DropdownMenuItem(
                                        text = { Text(type) },
                                        onClick = {
                                            selectedLoanType = type
                                            loanTypeExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Branch State Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchStateExpanded,
                        onExpandedChange = { branchStateExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchState,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch State") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchStateExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchStateExpanded,
                            onDismissRequest = { branchStateExpanded = false }
                        ) {
                            if (state.isLoading) {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator()
                                }
                            } else if (state.branchStates.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No states available") },
                                    onClick = { }
                                )
                            } else {
                                state.branchStates.forEach { state ->
                                    DropdownMenuItem(
                                        text = { Text(state) },
                                        onClick = {
                                            selectedBranchState = state
                                            branchStateExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Branch Location Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchLocationExpanded,
                        onExpandedChange = { branchLocationExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchLocation,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch Location") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchLocationExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchLocationExpanded,
                            onDismissRequest = { branchLocationExpanded = false }
                        ) {
                            if (state.isLoading) {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator()
                                }
                            } else if (state.branchLocations.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No locations available") },
                                    onClick = { }
                                )
                            } else {
                                state.branchLocations.forEach { location ->
                                    DropdownMenuItem(
                                        text = { Text(location) },
                                        onClick = {
                                            selectedBranchLocation = location
                                            branchLocationExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Filter Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = {
                                selectedVendorBank = ""
                                selectedLoanType = ""
                                selectedBranchState = ""
                                selectedBranchLocation = ""
                            },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                // TODO: Implement filter functionality
                            }
                        ) {
                            Text("Filter")
                        }
                    }
                }
            }

            // Table Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Vendor Bank",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "DSA Code",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "DSA Name",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Loan Type",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "State",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Location",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Table Content
                    dsaCodes.forEach { dsaCode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                dsaCode.vendorBank,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                dsaCode.dsaCode,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                dsaCode.dsaName,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                dsaCode.loanType,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                dsaCode.state,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                dsaCode.location,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BankersPanel(onDismiss: () -> Unit) {
    var selectedVendorBank by remember { mutableStateOf("") }
    var selectedLoanType by remember { mutableStateOf("") }
    var selectedBranchState by remember { mutableStateOf("") }
    var selectedBranchLocation by remember { mutableStateOf("") }
    
    var vendorBankExpanded by remember { mutableStateOf(false) }
    var loanTypeExpanded by remember { mutableStateOf(false) }
    var branchStateExpanded by remember { mutableStateOf(false) }
    var branchLocationExpanded by remember { mutableStateOf(false) }
    
    val vendorBanks = listOf("Bank 1", "Bank 2", "Bank 3")
    val loanTypes = listOf("Type 1", "Type 2", "Type 3")
    val branchStates = listOf("State 1", "State 2", "State 3")
    val branchLocations = listOf("Location 1", "Location 2", "Location 3")

    // Sample data for the table
    val bankers = remember {
        listOf(
            BankerData(
                vendorBank = "Bank 1",
                bankerName = "John Doe",
                bankerDesignation = "Manager",
                mobileNumber = "9876543210",
                email = "john@example.com",
                loanType = "Type 1",
                state = "State 1",
                location = "Location 1",
                visitingCard = "card1.pdf"
            ),
            BankerData(
                vendorBank = "Bank 2",
                bankerName = "Jane Smith",
                bankerDesignation = "Assistant Manager",
                mobileNumber = "9876543211",
                email = "jane@example.com",
                loanType = "Type 2",
                state = "State 2",
                location = "Location 2",
                visitingCard = "card2.pdf"
            )
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Bankers List",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Filter Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Vendor Bank Dropdown
                    ExposedDropdownMenuBox(
                        expanded = vendorBankExpanded,
                        onExpandedChange = { vendorBankExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedVendorBank,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Vendor Bank") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = vendorBankExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = vendorBankExpanded,
                            onDismissRequest = { vendorBankExpanded = false }
                        ) {
                            vendorBanks.forEach { bank ->
                                DropdownMenuItem(
                                    text = { Text(bank) },
                                    onClick = {
                                        selectedVendorBank = bank
                                        vendorBankExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Loan Type Dropdown
                    ExposedDropdownMenuBox(
                        expanded = loanTypeExpanded,
                        onExpandedChange = { loanTypeExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedLoanType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Loan Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = loanTypeExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = loanTypeExpanded,
                            onDismissRequest = { loanTypeExpanded = false }
                        ) {
                            loanTypes.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type) },
                                    onClick = {
                                        selectedLoanType = type
                                        loanTypeExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Branch State Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchStateExpanded,
                        onExpandedChange = { branchStateExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchState,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch State") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchStateExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchStateExpanded,
                            onDismissRequest = { branchStateExpanded = false }
                        ) {
                            branchStates.forEach { state ->
                                DropdownMenuItem(
                                    text = { Text(state) },
                                    onClick = {
                                        selectedBranchState = state
                                        branchStateExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Branch Location Dropdown
                    ExposedDropdownMenuBox(
                        expanded = branchLocationExpanded,
                        onExpandedChange = { branchLocationExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranchLocation,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Branch Location") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchLocationExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .padding(bottom = 16.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = branchLocationExpanded,
                            onDismissRequest = { branchLocationExpanded = false }
                        ) {
                            branchLocations.forEach { location ->
                                DropdownMenuItem(
                                    text = { Text(location) },
                                    onClick = {
                                        selectedBranchLocation = location
                                        branchLocationExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Filter and Reset Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = {
                                selectedVendorBank = ""
                                selectedLoanType = ""
                                selectedBranchState = ""
                                selectedBranchLocation = ""
                            },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("Reset")
                        }
                        Button(
                            onClick = {
                                // TODO: Implement filter functionality
                            }
                        ) {
                            Text("Filter")
                        }
                    }
                }
            }

            // Table Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Vendor Bank",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Banker Name",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Designation",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Mobile",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Email",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Loan Type",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "State",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Location",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Visiting Card",
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Table Content
                    bankers.forEach { banker ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                banker.vendorBank,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.bankerName,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.bankerDesignation,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.mobileNumber,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.email,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.loanType,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.state,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.location,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                banker.visitingCard,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Divider()
                    }
                }
            }
        }
    }
}

data class DsaCodeData(
    val vendorBank: String,
    val dsaCode: String,
    val dsaName: String,
    val loanType: String,
    val state: String,
    val location: String
)

data class BankerData(
    val vendorBank: String,
    val bankerName: String,
    val bankerDesignation: String,
    val mobileNumber: String,
    val email: String,
    val loanType: String,
    val state: String,
    val location: String,
    val visitingCard: String
)

@Composable
fun StatisticsBox(
    title: String,
    count: String,
    amount: String? = null
) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .padding(horizontal = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = count,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            if (amount != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Total Amount: $amount",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun StatisticsSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = "Statistics",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        
        val statistics = listOf(
            Triple("Total My Portfolio", "0", "0.00"),
            Triple("Total Team Portfolio", "0", "0.00"),
            Triple("Team SAL Data", "0", null),
            Triple("Team SENP Data", "0", null),
            Triple("Team SEP Data", "0", null),
            Triple("Team NRI Data", "0", null),
            Triple("Team Educational Data", "0", null),
            Triple("Team SAL Appt", "0", null),
            Triple("Team SENP Appt", "0", null),
            Triple("Team SEP Appt", "0", null),
            Triple("Team NRI Appt", "0", null),
            Triple("Team Educational Appt", "0", null),
            Triple("Total Partners", "0", null),
            Triple("Total Connectors", "0", null),
            Triple("Total Agents", "0", null)
        )
        
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) {
            items(statistics) { (title, count, amount) ->
                StatisticsBox(
                    title = title,
                    count = count,
                    amount = amount
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyAccountPanel(
    onNavigateBack: () -> Unit,
    onLogout: () -> Unit,
    viewModel: MainPanelViewModel = hiltViewModel()
) {
    var showLogoutDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val firstName by viewModel.userFirstName.collectAsState()
    val lastName by viewModel.userLastName.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onNavigateBack,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "My Account",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // User Information Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User",
                        modifier = Modifier
                            .size(80.dp)
                            .padding(bottom = 16.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    
                    Text(
                        text = if (firstName != null && lastName != null) {
                            "$firstName $lastName"
                        } else {
                            "User"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }

            // Settings Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    // Notification Settings
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Push Notifications")
                        Switch(
                            checked = true, // Replace with actual setting
                            onCheckedChange = { /* Handle notification setting change */ }
                        )
                    }
                    
                    // Dark Mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Dark Mode")
                        Switch(
                            checked = false, // Replace with actual setting
                            onCheckedChange = { /* Handle dark mode setting change */ }
                        )
                    }
                }
            }

            // Logout Button
            Button(
                onClick = { showLogoutDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = "Logout")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Logout")
            }
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Logout") },
            text = { Text("Are you sure you want to logout?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutDialog = false
                        onLogout()
                    }
                ) {
                    Text("Yes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("No")
                }
            }
        )
    }
} 

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpPanel(
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Help & Support",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // FAQ Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Frequently Asked Questions",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // FAQ Items
                    FaqItem(
                        question = "How do I add a new appointment?",
                        answer = "Click on 'Add Appointment' in the Appointments section. Fill in the required details and submit the form."
                    )

                    FaqItem(
                        question = "How do I view my appointments?",
                        answer = "Go to the Appointments section and select the type of appointment you want to view (SAL, SENP, SEP, etc.)."
                    )

                    FaqItem(
                        question = "How do I manage my team?",
                        answer = "Use the Team section to view and manage your team members' appointments and performance."
                    )

                    FaqItem(
                        question = "How do I upload files?",
                        answer = "Go to the Files section and use the file upload feature to add new documents."
                    )
                }
            }

            // Contact Support Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Contact Support",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Support Contact Items
                    SupportContactItem(
                        icon = Icons.Default.Email,
                        title = "Email Support",
                        description = "support@kurakulas.com"
                    )

                    SupportContactItem(
                        icon = Icons.Default.Phone,
                        title = "Phone Support",
                        description = "+91 1800-XXX-XXXX"
                    )

                    SupportContactItem(
                        icon = Icons.Default.Chat,
                        title = "Live Chat",
                        description = "Available 24/7"
                    )
                }
            }

            // Quick Links Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Quick Links",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Quick Link Items
                    QuickLinkItem(
                        title = "User Guide",
                        onClick = { /* TODO: Open user guide */ }
                    )

                    QuickLinkItem(
                        title = "Video Tutorials",
                        onClick = { /* TODO: Open video tutorials */ }
                    )

                    QuickLinkItem(
                        title = "Terms of Service",
                        onClick = { /* TODO: Open terms of service */ }
                    )

                    QuickLinkItem(
                        title = "Privacy Policy",
                        onClick = { /* TODO: Open privacy policy */ }
                    )
                }
            }
        }
    }
}

@Composable
private fun FaqItem(
    question: String,
    answer: String
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = question,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = if (expanded) "Collapse" else "Expand"
            )
        }
        
        if (expanded) {
            Text(
                text = answer,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        Divider(modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun SupportContactItem(
    icon: ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            modifier = Modifier.padding(end = 16.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun QuickLinkItem(
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge
        )
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Open $title"
        )
    }
} 