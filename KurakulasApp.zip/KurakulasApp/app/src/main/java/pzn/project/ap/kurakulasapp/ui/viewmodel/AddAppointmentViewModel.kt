package pzn.project.ap.kurakulasapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pzn.project.ap.kurakulasapp.data.model.State
import pzn.project.ap.kurakulasapp.data.model.Location
import pzn.project.ap.kurakulasapp.data.model.Sublocation
import pzn.project.ap.kurakulasapp.data.repository.LocationRepository
import javax.inject.Inject

data class AddAppointmentState(
    val mobileNumber: String = "",
    val name: String = "",
    val emailId: String = "",
    val companyName: String = "",
    val alternativeNumber: String = "",
    val selectedState: String = "",
    val selectedLocation: String = "",
    val selectedSubLocation: String = "",
    val selectedPincode: String = "",
    val selectedSource: String = "",
    val visitingCardUri: String? = null,
    val qualifications: String = "",
    val residentialAddress: String = "",
    val selectedCustomerType: String = "",
    // Bank Account Details
    val selectedBankName: String = "",
    val selectedAccountType: String = "",
    val accountNumber: String = "",
    val branchName: String = "",
    val ifscCode: String = "",
    // Loan Details
    val selectedLoanBankName: String = "",
    val selectedLoanType: String = "",
    val loanAmount: String = "",
    val selectedROI: String = "",
    val selectedTenure: String = "",
    val emi: String = "",
    val firstEmiDate: String = "",
    val lastEmiDate: String = "",
    val loanAccountNumber: String = "",
    // Vehicle Details
    val vehicleNumber: String = "",
    val selectedMake: String = "",
    val selectedModel: String = "",
    val selectedManYear: String = "",
    val engineNumber: String = "",
    val chassisNumber: String = "",
    // Property Details
    val selectedPropertyType: String = "",
    val area: String = "",
    val landInSqYards: String = "",
    val sft: String = "",
    val marketValue: String = "",
    // Credit Card Details
    val selectedCreditCardBank: String = "",
    val creditCardLimit: String = "",
    // Appointment Details
    val selectedAppointmentBank: String = "",
    val selectedAppointmentProduct: String = "",
    val selectedAppointmentStatus: String = "",
    val selectedAppointmentSubStatus: String = "",
    val appointmentNote: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class AddAppointmentViewModel @Inject constructor(
    private val locationRepository: LocationRepository
) : ViewModel() {
    private val _state = MutableStateFlow(AddAppointmentState())
    val state: StateFlow<AddAppointmentState> = _state.asStateFlow()

    private val _states = MutableStateFlow<List<State>>(emptyList())
    val states: StateFlow<List<State>> = _states.asStateFlow()

    private val _locations = MutableStateFlow<List<Location>>(emptyList())
    val locations: StateFlow<List<Location>> = _locations.asStateFlow()

    private val _sublocations = MutableStateFlow<List<Sublocation>>(emptyList())
    val sublocations: StateFlow<List<Sublocation>> = _sublocations.asStateFlow()

    private val _selectedState = MutableStateFlow<State?>(null)
    val selectedState: StateFlow<State?> = _selectedState.asStateFlow()

    private val _selectedLocation = MutableStateFlow<Location?>(null)
    val selectedLocation: StateFlow<Location?> = _selectedLocation.asStateFlow()

    private val _selectedSublocation = MutableStateFlow<Sublocation?>(null)
    val selectedSublocation: StateFlow<Sublocation?> = _selectedSublocation.asStateFlow()

    init {
        loadStates()
    }

    private fun loadStates() {
        viewModelScope.launch {
            _states.value = locationRepository.getStates()
        }
    }

    fun onStateSelected(state: State) {
        viewModelScope.launch {
            _selectedState.value = state
            _selectedLocation.value = null
            _selectedSublocation.value = null
            val locationsForState = locationRepository.getLocationsForState(state.id)
            _locations.value = locationsForState
            // Only clear sublocations if there are no locations
            if (locationsForState.isEmpty()) {
                _sublocations.value = emptyList()
            }
        }
    }

    fun onLocationSelected(location: Location) {
        viewModelScope.launch {
            _selectedLocation.value = location
            _selectedSublocation.value = null
            val sublocationsForLocation = locationRepository.getSublocationsForLocation(location.id)
            _sublocations.value = sublocationsForLocation
        }
    }

    fun onSublocationSelected(sublocation: Sublocation) {
        _selectedSublocation.value = sublocation
    }

    fun updateMobileNumber(number: String) {
        _state.update { it.copy(mobileNumber = number) }
    }

    fun updateName(name: String) {
        _state.update { it.copy(name = name) }
    }

    fun updateEmailId(email: String) {
        _state.update { it.copy(emailId = email) }
    }

    fun updateCompanyName(company: String) {
        _state.update { it.copy(companyName = company) }
    }

    fun updateAlternativeNumber(number: String) {
        _state.update { it.copy(alternativeNumber = number) }
    }

    fun updateState(state: String) {
        _state.update { it.copy(selectedState = state) }
    }

    fun updateLocation(location: String) {
        _state.update { it.copy(selectedLocation = location) }
    }

    fun updateSubLocation(subLocation: String) {
        _state.update { it.copy(selectedSubLocation = subLocation) }
    }

    fun updatePincode(pincode: String) {
        _state.update { it.copy(selectedPincode = pincode) }
    }

    fun updateSource(source: String) {
        _state.update { it.copy(selectedSource = source) }
    }

    fun updateVisitingCardUri(uri: String?) {
        _state.update { it.copy(visitingCardUri = uri) }
    }

    fun updateQualifications(qualifications: String) {
        _state.update { it.copy(qualifications = qualifications) }
    }

    fun updateResidentialAddress(address: String) {
        _state.update { it.copy(residentialAddress = address) }
    }

    fun updateCustomerType(type: String) {
        _state.update { it.copy(selectedCustomerType = type) }
    }

    // Bank Account Details
    fun updateBankName(bankName: String) {
        _state.update { it.copy(selectedBankName = bankName) }
    }

    fun updateAccountType(accountType: String) {
        _state.update { it.copy(selectedAccountType = accountType) }
    }

    fun updateAccountNumber(accountNumber: String) {
        _state.update { it.copy(accountNumber = accountNumber) }
    }

    fun updateBranchName(branchName: String) {
        _state.update { it.copy(branchName = branchName) }
    }

    fun updateIfscCode(ifscCode: String) {
        _state.update { it.copy(ifscCode = ifscCode) }
    }

    fun addBankAccount() {
        // TODO: Implement bank account addition logic
    }

    // Loan Details
    fun updateLoanBankName(bankName: String) {
        _state.update { it.copy(selectedLoanBankName = bankName) }
    }

    fun updateLoanType(loanType: String) {
        _state.update { it.copy(selectedLoanType = loanType) }
    }

    fun updateLoanAmount(amount: String) {
        _state.update { it.copy(loanAmount = amount) }
    }

    fun updateROI(roi: String) {
        _state.update { it.copy(selectedROI = roi) }
    }

    fun updateTenure(tenure: String) {
        _state.update { it.copy(selectedTenure = tenure) }
    }

    fun updateEMI(emi: String) {
        _state.update { it.copy(emi = emi) }
    }

    fun updateFirstEmiDate(date: String) {
        _state.update { it.copy(firstEmiDate = date) }
    }

    fun updateLastEmiDate(date: String) {
        _state.update { it.copy(lastEmiDate = date) }
    }

    fun updateLoanAccountNumber(accountNumber: String) {
        _state.update { it.copy(loanAccountNumber = accountNumber) }
    }

    fun addLoanDetails() {
        // TODO: Implement loan details addition logic
    }

    fun submitAppointment() {
        // TODO: Implement appointment submission logic
        // This should include validation and API calls
    }

    // Vehicle Details
    fun updateVehicleNumber(number: String) {
        _state.update { it.copy(vehicleNumber = number) }
    }

    fun updateMake(make: String) {
        _state.update { it.copy(selectedMake = make) }
    }

    fun updateModel(model: String) {
        _state.update { it.copy(selectedModel = model) }
    }

    fun updateManYear(year: String) {
        _state.update { it.copy(selectedManYear = year) }
    }

    fun updateEngineNumber(number: String) {
        _state.update { it.copy(engineNumber = number) }
    }

    fun updateChassisNumber(number: String) {
        _state.update { it.copy(chassisNumber = number) }
    }

    fun addVehicleDetails() {
        // TODO: Implement vehicle details addition logic
    }

    // Property Details
    fun updatePropertyType(type: String) {
        _state.update { it.copy(selectedPropertyType = type) }
    }

    fun updateArea(area: String) {
        _state.update { it.copy(area = area) }
    }

    fun updateLandInSqYards(land: String) {
        _state.update { it.copy(landInSqYards = land) }
    }

    fun updateSFT(sft: String) {
        _state.update { it.copy(sft = sft) }
    }

    fun updateMarketValue(value: String) {
        _state.update { it.copy(marketValue = value) }
    }

    fun addPropertyDetails() {
        // TODO: Implement property details addition logic
    }

    // Credit Card Details
    fun updateCreditCardBank(bank: String) {
        _state.update { it.copy(selectedCreditCardBank = bank) }
    }

    fun updateCreditCardLimit(limit: String) {
        _state.update { it.copy(creditCardLimit = limit) }
    }

    fun addCreditCardDetails() {
        // TODO: Implement credit card details addition logic
    }

    // Appointment Details
    fun updateAppointmentBank(bank: String) {
        _state.update { it.copy(selectedAppointmentBank = bank) }
    }

    fun updateAppointmentProduct(product: String) {
        _state.update { it.copy(selectedAppointmentProduct = product) }
    }

    fun updateAppointmentStatus(status: String) {
        _state.update { it.copy(selectedAppointmentStatus = status) }
    }

    fun updateAppointmentSubStatus(subStatus: String) {
        _state.update { it.copy(selectedAppointmentSubStatus = subStatus) }
    }

    fun updateAppointmentNote(note: String) {
        _state.update { it.copy(appointmentNote = note) }
    }
} 