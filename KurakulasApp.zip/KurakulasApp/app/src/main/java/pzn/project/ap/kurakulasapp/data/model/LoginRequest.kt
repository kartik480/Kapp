package pzn.project.ap.kurakulasapp.data.model

data class LoginRequest(
    val username: String,
    val password: String
) 