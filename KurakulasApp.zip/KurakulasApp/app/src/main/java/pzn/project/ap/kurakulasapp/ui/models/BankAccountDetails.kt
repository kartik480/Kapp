package pzn.project.ap.kurakulasapp.ui.models

data class BankAccountDetails(
    val bankName: String,
    val accountType: String,
    val accountNumber: String,
    val branchName: String,
    val ifscCode: String
) 