package pzn.api

data class VehicleModelResponse(
    val success: Boolean,
    val message: String,
    val data: List<String>
) 