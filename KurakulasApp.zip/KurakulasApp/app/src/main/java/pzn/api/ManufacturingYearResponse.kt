package pzn.api

data class ManufacturingYearResponse(
    val success: Boolean,
    val message: String,
    val data: List<String>
) 