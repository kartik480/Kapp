<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once 'db_config.php';

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die(json_encode([
        "success" => false,
        "message" => "Database connection failed"
    ]));
}

try {
    // Check if this is a POST request
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get the raw POST data
        $raw_data = file_get_contents("php://input");
        $data = json_decode($raw_data, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON data");
        }

        // Start transaction
        $conn->begin_transaction();

        try {
            // Insert into tbl_appointment
            $appointmentColumns = [
                'database_id',
                'mobile_number',
                'lead_name',
                'email_id',
                'company_name',
                'alternative_mobile',
                'state',
                'location',
                'sub_location',
                'pin_code',
                'source',
                'visiting_card',
                'user_qualification',
                'residental_address',
                'customer_type'
            ];

            $appointmentValues = [];
            $appointmentParams = [];

            foreach ($appointmentColumns as $column) {
                if (isset($data[$column])) {
                    $appointmentValues[] = "?";
                    $appointmentParams[] = $data[$column];
                }
            }

            $appointmentSql = "INSERT INTO tbl_appointment (" . 
                implode(', ', array_map(function($col) { return "`$col`"; }, $appointmentColumns)) . 
                ") VALUES (" . implode(', ', $appointmentValues) . ")";

            $stmt = $conn->prepare($appointmentSql);
            if (!$stmt) {
                throw new Exception("Error preparing appointment statement: " . $conn->error);
            }

            $stmt->bind_param(str_repeat('s', count($appointmentParams)), ...$appointmentParams);
            if (!$stmt->execute()) {
                throw new Exception("Error inserting appointment: " . $stmt->error);
            }

            $appointmentId = $conn->insert_id;

            // Insert into tbl_database_calling_status
            $callingStatusColumns = [
                'database_id',
                'appt_bank',
                'appt_product',
                'appt_status',
                'appt_sub_status'
            ];

            $callingStatusValues = [];
            $callingStatusParams = [];

            foreach ($callingStatusColumns as $column) {
                if (isset($data[$column])) {
                    $callingStatusValues[] = "?";
                    $callingStatusParams[] = $data[$column];
                }
            }

            $callingStatusSql = "INSERT INTO tbl_database_calling_status (" . 
                implode(', ', array_map(function($col) { return "`$col`"; }, $callingStatusColumns)) . 
                ") VALUES (" . implode(', ', $callingStatusValues) . ")";

            $stmt = $conn->prepare($callingStatusSql);
            if (!$stmt) {
                throw new Exception("Error preparing calling status statement: " . $conn->error);
            }

            $stmt->bind_param(str_repeat('s', count($callingStatusParams)), ...$callingStatusParams);
            if (!$stmt->execute()) {
                throw new Exception("Error inserting calling status: " . $stmt->error);
            }

            // Commit transaction
            $conn->commit();

            echo json_encode([
                "success" => true,
                "message" => "Appointment and calling status added successfully",
                "appointment_id" => $appointmentId
            ]);

        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            throw $e;
        }

    } else {
        throw new Exception("Invalid request method");
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}

$conn->close();
?> 